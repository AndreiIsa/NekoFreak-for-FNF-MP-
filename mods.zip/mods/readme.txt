************************ SONGS ************************

	HOW TO USE SONGS.TXT

For adding songs in a desired order, you just have to add the folder name of your
custom song(s) to songs.txt, inside mods/charts/ folder, in the order you want
them to be, if you don't care about the song order, simply don't do shit.

************************ CHARACTERS ************************

Similar to songs.txt, you can use characters.txt to add characters in a
specific order of your preference.



CREATING A CUSTOM CHART

Let's say your custom song is named "chart", this is how your custom song folder
should be looking like:

	chart-easy.json
	chart.json
	chart-hard.json
	Inst.ogg
	Voices.ogg (NOT NEEDED IF YOU DISABLED VOCALS ON YOUR CHART)
	config.json